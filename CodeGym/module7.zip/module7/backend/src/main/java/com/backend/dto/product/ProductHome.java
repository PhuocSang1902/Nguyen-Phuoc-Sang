package com.backend.dto.product;

public interface ProductHome {
    Integer getId();

    Long getCode();

    String getName();

    int getCost();

    String getImage();
}
