export interface OrderDetailList {
  id?: number;

  idProduct?: number;

  code?: number;

  name?: string;

  cost?: number;

  image?: string;

  numberOfProduct?: number;

  totalCost?: number;
}
