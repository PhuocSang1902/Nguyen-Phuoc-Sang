export interface SignInForm {
  email?: string;
  password?: string;
}
