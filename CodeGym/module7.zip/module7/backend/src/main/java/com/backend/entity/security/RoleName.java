package com.backend.entity.security;

public enum RoleName {
    ROLE_ADMIN,
    ROLE_USER
}
