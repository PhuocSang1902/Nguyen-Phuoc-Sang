export interface ProductHome {
  id?: number;
  code?: number;
  name?: string;
  cost?: number;
  image?: string;
}
