package com.backend.dto.cart;

public interface CartTotal {
    int getTotalProduct();
    int getTotalCost();
}
