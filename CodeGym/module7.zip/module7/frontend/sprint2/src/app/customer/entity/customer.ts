export interface Customer {
  id?: number;
  name?: string;
  email?: string;
  address?: string;
  gender?: string;
  birthday?: string;
  phone?: string;
  encryptPassword?: string;
}
