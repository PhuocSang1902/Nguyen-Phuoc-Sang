export interface CartTotal {
  totalProduct?: number;
  totalCost?: number;
}
