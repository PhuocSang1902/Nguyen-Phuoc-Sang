export interface OrderDetail {
  id?: number;
  idProduct?: number;
  numberOfProduct?: number;
}
