export interface CartList {
  id?: number;

  idProduct?: number;

  code?: number;

  name?: string;

  cost?: number;

  image?: string;

  idCustomer?: number;

  numberOfProduct?: number;

  totalCost?: number;
}
