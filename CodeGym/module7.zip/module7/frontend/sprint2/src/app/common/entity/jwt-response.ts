export interface JwtResponse {
  token?: string;
  id?: number;
  name?: string;
  avatar?: string;
  roles?: any[];
}
